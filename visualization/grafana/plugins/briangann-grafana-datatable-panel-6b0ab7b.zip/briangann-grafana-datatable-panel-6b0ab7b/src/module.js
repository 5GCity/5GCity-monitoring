import {DatatablePanelCtrl} from  './ctrl';

export {
  DatatablePanelCtrl as PanelCtrl
};
